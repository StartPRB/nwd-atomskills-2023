import axios from "axios";

class MachineHelper {
  static controllerName = "Machine";

  /**
   * Получить все записи по странично
   * @param {params} Параметры запроса
   * @returns {array}
   */
  static async Check(server) {
    let url = `${server}/api/${this.controllerName}/Check/`;
    return axios
      .get(url)
      .then((response) => {
        return { success: true, data: response.data };
      })
      .catch((error) => {
        console.log(error);
        return { success: false, data: "Ошибка при попытки отправить запрос на сервер" };
      });
  }
}

export default MachineHelper;
