import React from "react";
import styles from "./App.module.scss";
import { Grid, Box, Paper, Stack, Table, TextField, Button, Typography } from "@mui/material";
import { formatDate } from "./Func";
import RequestHelper from "./helpers/RequestHelper";
import MachineHelper from "./helpers/MachineHelper";

import { useSnackbar } from "notistack";

export const App = ({}) => {
  const [Server, setServer] = React.useState("");
  const [value, setValue] = React.useState("");
  const { enqueueSnackbar } = useSnackbar();
  React.useEffect(() => {
    const timer = setInterval(() => {
      if (Server !== "") {
        RequestHelper.Check(Server)
          .then((res) => {
            if (res.success) {
              enqueueSnackbar("Опрос заявок завершен от " + formatDate(Date.now(), "full"), { variant: "success" });
            } else {
              enqueueSnackbar("Ошибка при запросе к серверу " + Server + " от " + formatDate(Date.now(), "full"), { variant: "error" });
            }
          })
          .catch((error) => {
            enqueueSnackbar("Ошибка при запросе к серверу " + Server + " от " + formatDate(Date.now(), "full"), { variant: "error" });
          })
          .finally(() => {
            //
          });

        MachineHelper.Check(Server)
          .then((res) => {
            if (res.success) {
              enqueueSnackbar("Опрос станков завершен от " + formatDate(Date.now(), "full"), { variant: "success" });
            } else {
              enqueueSnackbar("Ошибка при запросе к серверу " + Server + " от " + formatDate(Date.now(), "full"), { variant: "error" });
            }
          })
          .catch((error) => {
            enqueueSnackbar("Ошибка при запросе к серверу " + Server + " от " + formatDate(Date.now(), "full"), { variant: "error" });
          })
          .finally(() => {
            //
          });
      }
    }, 5000);
    return () => clearInterval(timer);
  });

  const handleClick = (e) => {
    setServer(value);
  };

  const MainTitle = () => {
    const [time, setTime] = React.useState(new Date().toLocaleTimeString());
    React.useEffect(() => {
      const timer = setInterval(() => {
        setTime(new Date().toLocaleTimeString());
      }, 1000);
      return () => clearInterval(timer);
    });
    return (
      <>
        <Box sx={{ display: "flex", justifyContent: "center", alignItems: "center", m: 3 }}>
          <Box sx={{ display: "flex", flexDirection: "column", justifyContent: "center", alignItems: "center", p: 3, minWidth: "250px", backgroundColor: "rgba(255,255,255,0.75)" }}>
            <Typography variant="h4">{time}</Typography>
            <Typography variant="h6" sx={{ textAlign: "center" }}>
              {formatDate(Date.now())}
            </Typography>
          </Box>
        </Box>
      </>
    );
  };

  document.title = "AS2023";

  return (
    <React.Fragment>
      <div className={styles.App}>
        <Grid container spacing={3}>
          <Grid item xs={12}>
            <MainTitle />
          </Grid>
          {Server === "" ? (
            <Grid item xs={12} sx={{ display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center" }}>
              <Box sx={{ display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", p: 5, backgroundColor: "rgba(255,255,255,1)" }}>
                <Grid container>
                  <Grid item xs={12} sx={{ textAlign: "center" }}>
                    <Typography variant="h3">Введите адрес сервера</Typography>
                  </Grid>
                  <Grid item xs={8}>
                    <TextField onChange={(e) => setValue(e.target.value)} label="Адрес сервера" variant="outlined" fullWidth />
                  </Grid>
                  <Grid item xs={4} sx={{ display: "flex", justifyContent: "center", alignItems: "center" }}>
                    <Button variant="contained" size="large" onClick={handleClick}>
                      Сохранить
                    </Button>
                  </Grid>
                  <Grid item xs={12} sx={{ textAlign: "center" }}>
                    <Typography>Например: http://localhost:62394</Typography>
                  </Grid>
                </Grid>
              </Box>
            </Grid>
          ) : null}
        </Grid>
      </div>
    </React.Fragment>
  );
};

export default App;
