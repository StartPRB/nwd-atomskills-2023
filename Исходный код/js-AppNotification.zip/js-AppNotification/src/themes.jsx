import { blueGrey, grey, lightBlue, yellow } from "@mui/material/colors";
import { createTheme } from "@mui/material/styles";
import { ruRU } from "@mui/material/locale";
import { ruRU as ruRU_XDataGrid } from "@mui/x-data-grid";

export const lightTheme = createTheme(
  {
    palette: {
      mode: "light",
      bg: {
        main: grey[300],
      },
      light: {
        main: grey[100],
      },
      secondary: {
        main: blueGrey[600],
      },
      warning: {
        main: yellow[800],
      },
    },
    typography: {
      hint: {
        fontFamily: "Roboto, Helvetica, Arial, sans-serif",
        fontWeight: 400,
        fontSize: "0.75rem",
        lineHeight: 1.66,
        letterSpacing: "0.033em",
        color: "#f57c00",
      },
    },
  },
  ruRU_XDataGrid,
  ruRU
);

export const darkTheme = createTheme(
  {
    palette: {
      mode: "dark",
      bg: {
        main: grey[800],
      },
      light: {
        main: grey[100],
      },
      primary: {
        main: lightBlue[700],
        dark: lightBlue[900],
      },
      secondary: {
        main: blueGrey[600],
      },
      warning: {
        main: yellow[600],
      },
    },
    typography: {
      hint: {
        fontFamily: "Roboto, Helvetica, Arial, sans-serif",
        fontWeight: 400,
        fontSize: "0.75rem",
        lineHeight: 1.66,
        letterSpacing: "0.033em",
        color: "#f57c00",
      },
    },
  },
  ruRU_XDataGrid,
  ruRU
);
