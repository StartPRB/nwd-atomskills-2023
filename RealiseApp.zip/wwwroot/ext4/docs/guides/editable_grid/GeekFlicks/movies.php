<?php
header("Content-type: application/json");
?>
{
  "success": true,
  "data": [{
      "title": "The Matrix",
      "year": "1999"
  }, {
      "title": "Star Wars: Return of the Jedi",
      "year": "1983"
  }]
}
